 set -v
 cd /sys/kernel/debug/apei/einj
 cat error_type
 echo 0x10 >error_type
 echo $1 > param1
 echo 0xfffffffffffff000 >param2
 echo 0 >notrigger
 echo 1 > error_inject
 

